# -*- encoding: utf-8 -*-
'''
@File    :   __init__.py
@Time    :   2023/07/11 21:06:55
@Author  :   HMX
@Version :   1.0
@Contact :   kzdhb8023@163.com
'''

# here put the import lib
from .mxclf import *
from .mxgdal import *
from .mxgee import *
from .mxgpd import *


__version__ = "0.1.8"